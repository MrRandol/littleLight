/**
  BUNGIE OAuth

  Process is the folowwing :

  1/ Call code redeem from app code & oauth url
  2/ wait for callback on app specific url
  3/ Extract code from return url and call for access Token
  4/ Extract & save access & refresh token
**/

/**
  REACT IMPORTS & INITS
**/
import React from 'react';
import { Linking, View, Text, Button } from 'react-native';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import * as Actions from '../actions';

function mapStateToProps(state) { return {user: state.user.user}; };
function mapDispatchToProps(dispatch) { return bindActionCreators(Actions, dispatch); }

/**
  CUSTOM IMPORTS
**/
import * as Store from '../utils/store/authStore';
import * as Message from '../utils/message';

const OAUTH_CODE_URL = 'https://www.bungie.net/en/OAuth/Authorize?client_id=1037&response_type=code';
const OAUTH_TOKEN_URL = 'https://www.bungie.net/Platform/App/GetAccessTokensFromCode/';

const NO_AUTH = 'NO_AUTH';
const AUTH_CODE = 'AUTH_CODE';
const AUTH_CODE_SAVED = 'AUTH_CODE_SAVED';
const AUTH_TOKEN = 'AUTH_TOKEN';
const AUTH_TOKEN_VALID = 'AUTH_TOKEN_VALID';
const AUTH_TOKEN_INVALID = 'AUTH_TOKEN_INVALID';
const AUTH_REFRESH_TOKEN_INVALID = 'AUTH_REFRESH_TOKEN_INVALID';

class OauthLogin extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      auth_status: NO_AUTH
    };
  }

  componentDidMount() {
    Store.getAuthData().then(result => {
      if (result.status ==="SUCCESS" && result.data !== null && result.data.auth === true) {
        Message.debug("Logged in. No need to request.")
        //TODO : handle next step
      } else {
        Message.debug("Not logged in, launchin process...")
        // STEP 1 : redeem oauth code
        Linking.openURL(OAUTH_CODE_URL);
        Linking.addEventListener('url', this.handleOauthCodeCallback.bind(this));
      }
    })
  }

  componentWillUnmount() {
    Linking.removeEventListener('url', this.handleOauthCodeCallback);
  }

  handleOauthCodeCallback(event) {
    Linking.removeEventListener('url', this.handleOauthCodeCallback);

    Message.debug("Got called with following url");
    Message.debug(event.url);

    const error = event.url.toString().match( /error=([^&]+)/ );
    const code = event.url.toString().match( /code=([^&]+)/ );

    if ( error || !code) {
      Message.error( "error while loggin in : " + error ? error[1] : "UNKNOWN_ERROR" );
      return;
    }

    // STEP 2 : we have code, we save it and request token
    Message.debug("Got Bungie Code : " + code[1] );
    Message.debug(code[1]);
    this.setState({auth_status: AUTH_CODE});
    Store.saveAuthData({code: code[1]}).then(result => {
      if (result.status ==="SUCCESS") {
          Message.debug("Saved auth data!")
          this.setState({auth_status: AUTH_CODE_SAVED});
          // TODO : handle next step here
          this.requestAccessToken(code[1]);
      } else {
          Message.debug("error saving auth")
      }
    });
  }

  requestAccessToken(code) {
    // TODO : extract in common place with bungie.js
    const APIKEY = "ca9b21b2df144c04a0d4434e6ffe1aed";
    const HOST = "https://www.bungie.net/";

    var defaultHeaders = new Headers();
    defaultHeaders.append('X-API-Key', APIKEY);
    defaultHeaders.append('Content-Type', 'application/json; charset=UTF-8;');
    defaultHeaders.append('Origin', '*');

    var defaultParams = {
        headers: defaultHeaders,
        cache: 'default',
        mode: 'cors',
        // WARNING !! Different from original from here
        method: 'POST', 
        body: JSON.stringify({code: code})
    }

    try {
      Message.debug("Fetching OAuth token for code " + code);
      var url = "https://www.bungie.net/Platform/App/GetAccessTokensFromCode/";
      fetch(url, defaultParams)
        .then(function (resp) {
          return resp.json();
        }).then(function (json) {          
          Message.debug("Got answer for token : ");
          Message.debug(JSON.stringify(json));
        })
        .catch(() => { 
          Message.error("Error While fetching!")
        });
    } catch (error) {
       Message.error("Encountered error while launching OAuth token fetch.")
    }

  }


  render() {
    var headers = {
      'X-API-Key': 'ca9b21b2df144c04a0d4434e6ffe1aed'
    }
    if (this.state.displayLogin) {
    return (
      <Text> launch authent via browser </Text>

    );
  } else {
    return(
    <View>
      <Text> {this.state.auth_status} </Text>
      </View>
      )
  }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(OauthLogin);